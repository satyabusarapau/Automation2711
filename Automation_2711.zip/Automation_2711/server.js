const express = require('express');
const fs = require('fs');
const { exec } = require('child_process');
const app = express();
const dataFilePath = './data/servers.json';

app.use(express.json());
app.use(express.static('public')); // Serve static files from the 'public' folder

// Load initial servers data from JSON file
let servers = {};
fs.readFile(dataFilePath, 'utf8', (err, data) => {
  if (err) {
    console.error('Error reading servers data:', err);
    return;
  }
  servers = JSON.parse(data).servers;
});

// Route to serve the JSON data directly
app.get('/data/servers.json', (req, res) => {
  res.json({ servers });
});

// Route to handle start command
app.post('/start-server', (req, res) => {
  const { command } = req.body;
  exec(command, (error, stdout, stderr) => {
    if (error) {
      return res.json({ output: `Error: ${error.message}` });
    }
    if (stderr) {
      return res.json({ output: `Stderr: ${stderr}` });
    }
    res.json({ output: stdout });
  });
});

// Route to add a new server and command
app.post('/add-server-command', (req, res) => {
  const { serverName, command } = req.body;

  // Initialize server entry if it doesn't exist
  if (!servers[serverName]) {
    servers[serverName] = [];
  }

  // Add command to the server's command list
  servers[serverName].push({ value: command, text: `Command: ${command}` });

  // Write updated servers data back to the JSON file
  fs.writeFile(dataFilePath, JSON.stringify({ servers }, null, 2), (err) => {
    if (err) {
      console.error('Error writing to servers data:', err);
      return res.status(500).json({ message: 'Error saving server data.' });
    }
    res.json({ message: 'Server and command added successfully.' });
  });
});

// Route to delete a server and its commands
app.post('/delete-server', (req, res) => {
  const { serverName } = req.body;

  if (!servers[serverName]) {
    return res.status(404).json({ message: 'Server not found.' });
  }

  // Delete the server entry
  delete servers[serverName];

  // Write updated servers data back to the JSON file
  fs.writeFile(dataFilePath, JSON.stringify({ servers }, null, 2), (err) => {
    if (err) {
      console.error('Error writing to servers data:', err);
      return res.status(500).json({ message: 'Error deleting server data.' });
    }
    res.json({ message: 'Server deleted successfully.' });
  });
});

// Start the backend server
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
